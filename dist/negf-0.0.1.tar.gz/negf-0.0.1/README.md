# NEGF Calculaton

This project is a tool for calculating the quantum transport properties of condensed matter systems based on the
principle of non-equilibrium Green's functions(NEGF).

About the NEGF method, 《Quantum Transport -Atom to Transistor》-Supriyo Datta or https://zhuanlan.zhihu.com/p/269595149

This is an early version of the tool that is currently capable of performing iterative Green's function calculations
only. The specific calculation methods detail can be found in the code provided in the 'tests' folder.


